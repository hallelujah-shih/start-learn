/* Public domain. */

#ifndef OPENREADCLOSE_H
#define OPENREADCLOSE_H

#include "stralloc.h"

extern int openreadclose(const char *,stralloc *,unsigned int);

#endif
